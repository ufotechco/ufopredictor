"""
ufopredictor.

An example python library.
"""

__version__ = "0.1.0"
__author__ = 'Reynaldo Villarreal and Juan Pablo Pestana'
__credits__ = 'UFOTECH S.A.S.'